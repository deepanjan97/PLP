package com.capgemini.capbook.exceptions;

public class UserException extends Throwable {
	public UserException(String e)
	{
		super(e);
	}
	public UserException()
	{
		super();
	}

}