ignore e2e file
